from flask import Flask, render_template
import pickle

app = Flask(__name__)

@app.route('/')
def home():
    with open('show_movie_url_pic.pickle', 'rb') as f:
        movie_data = pickle.load(f)
    # 修改图片路径，使其相对于static目录
    for movie in movie_data:
        movie_data[movie][1] = movie_data[movie][1]
    return render_template('movie2.html', movie_data=movie_data)

if __name__ == '__main__':
    app.run(debug=True)