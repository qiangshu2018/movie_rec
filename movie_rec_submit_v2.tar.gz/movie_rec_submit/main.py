from flask import Flask, render_template

app = Flask(__name__)

# 假设这是电影数据
movies = [
    {"title": "The Shawshank Redemption", "year": 1994},
    {"title": "The Godfather", "year": 1972},
    {"title": "The Dark Knight", "year": 2008}
]

@app.route('/')
def index():
    # 将电影数据传递给模板
    return render_template('index_v2.html', movies=movies)

@app.route('/movie/<title>')
def movie_detail(title):
    # 在这里你可以根据电影名称进行详细信息的查找和展示
    return f"https://www.imdb.com/"

if __name__ == '__main__':
    app.run(debug=True)